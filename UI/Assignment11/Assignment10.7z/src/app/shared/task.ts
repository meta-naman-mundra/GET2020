export class Task{
    id: Number;
    title: string;
    description: string;
    status: string;
    creationDate: Date;
    completionDate: Date;
    priority: String;
}